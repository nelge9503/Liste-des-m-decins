# gestionM-decin
Gestionnaire d'une liste de médecin en PHP
Objectif : Créer un programme PHP afin de pouvoir gérer une liste de médecins, c’est-à-dire pouvoir modifier ou supprimer des médecins
Langage utiliser : PHP, CSS
